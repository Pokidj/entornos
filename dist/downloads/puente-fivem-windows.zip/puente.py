"""Puente local /entorno con bandeja Windows. No modifica FiveM ni el servidor."""
import argparse
import hmac
import json
import secrets
import socket
import struct
import threading
import time
import webbrowser
import os
import sys
from pathlib import Path
from urllib.parse import urlsplit
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ORIGIN = 'https://entorno-rp-radio-2710.balmyguppy1.chatgpt.site'
HOST = '127.0.0.1'
PORT = 39173
TOKEN = secrets.token_urlsafe(32)
SEND_LOCK = threading.Lock()
LAST_SEND = 0.0

WEB_URL = ORIGIN
BASE_DIR = Path(sys.executable).resolve().parent if getattr(sys, 'frozen', False) else Path(__file__).resolve().parent
CONFIG_PATH = BASE_DIR / 'configuracion.json'

def parse_site_url(value):
    if not isinstance(value, str):
        raise ValueError('La dirección debe ser un texto.')
    value = value.strip()
    if any(ord(c) < 32 for c in value):
        raise ValueError('Dirección no válida.')
    parsed = urlsplit(value)
    if parsed.scheme not in ('http', 'https') or not parsed.hostname or parsed.username or parsed.password:
        raise ValueError('Escribe una dirección completa http:// o https://, sin usuario ni contraseña.')
    if parsed.query or parsed.fragment:
        raise ValueError('Usa la dirección de la página sin parámetros ni fragmentos.')
    try:
        port = parsed.port
    except ValueError:
        raise ValueError('Puerto de la web no válido.')
    if port is not None and not 1 <= port <= 65535:
        raise ValueError('Puerto de la web no válido.')
    if any(c.isspace() or c in '\\/*' for c in parsed.hostname):
        raise ValueError('Dominio no válido.')
    host = parsed.hostname.encode('idna').decode('ascii').lower()
    if ':' in host:
        host = '[' + host + ']'
    if port and not (parsed.scheme == 'https' and port == 443 or parsed.scheme == 'http' and port == 80):
        host += ':' + str(port)
    origin = parsed.scheme + '://' + host
    return origin + (parsed.path or '/'), origin

def load_site_config():
    global WEB_URL, ORIGIN, TOKEN
    if not CONFIG_PATH.exists():
        return
    data = json.loads(CONFIG_PATH.read_text(encoding='utf-8-sig'))
    if not isinstance(data, dict):
        raise ValueError('La configuración debe ser un objeto JSON.')
    url, origin = parse_site_url(data.get('web_url'))
    if origin != ORIGIN:
        TOKEN = secrets.token_urlsafe(32)
    WEB_URL = url
    ORIGIN = origin

def normalize_command(value, slash=False):
    if not isinstance(value, str) or len(value) > 6000:
        raise ValueError('Texto no válido o demasiado largo.')
    if any(ord(c) < 32 or ord(c) == 127 for c in value):
        raise ValueError('El entorno no puede contener saltos de línea ni caracteres de control.')
    text = value.strip()
    if not text.lower().startswith('/entorno '):
        raise ValueError('Solo se permite /entorno seguido de texto.')
    body = text[len('/entorno '):].strip()
    if not body:
        raise ValueError('El entorno está vacío.')
    # Evitar separadores de consola y delimitar el texto como un solo argumento.
    body = body.replace(';', ',').replace('"', '”').replace('\\', '/')
    return ('/entorno' if slash else 'entorno') + ' "' + body + '"'

def frame(command):
    payload = command.encode('utf-8') + b'\n'
    return b'CMND\x00\xd3' + struct.pack('>I', len(payload) + 1) + b'\x00\x00' + payload + b'\x00'

def connect_console(port):
    sock = socket.create_connection((HOST, port), timeout=0.8)
    deadline = time.monotonic() + 1.2
    try:
        sock.sendall(b'PPCR')
        # FiveM confirma el protocolo con una cabecera AINF.
        data = b''
        while len(data) < 12:
            sock.settimeout(max(0.01, deadline - time.monotonic()))
            if time.monotonic() >= deadline:
                raise OSError('La consola no respondió a tiempo.')
            chunk = sock.recv(12-len(data))
            if not chunk:
                raise OSError('La consola cerró la conexión.')
            data += chunk
        if data[:4] != b'AINF':
            raise OSError('No se ha reconocido la consola de FiveM.')
        size = struct.unpack('>I', data[6:10])[0]
        if size < 12 or size > 1048576:
            raise OSError('Respuesta de consola no válida.')
        remaining = size - 12
        while remaining:
            if time.monotonic() >= deadline:
                raise OSError('La consola no respondió a tiempo.')
            sock.settimeout(max(0.01, deadline - time.monotonic()))
            chunk = sock.recv(min(remaining, 8192))
            if not chunk:
                raise OSError('Respuesta de consola incompleta.')
            remaining -= len(chunk)
        return sock
    except Exception:
        sock.close()
        raise

class BridgeServer(ThreadingHTTPServer):
    daemon_threads = True
    def get_request(self):
        connection, address = super().get_request()
        connection.settimeout(5)
        return connection, address

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass
    def allowed(self):
        return self.headers.get('Origin') == ORIGIN and self.headers.get('Host') == f'{HOST}:{PORT}'
    def respond(self, code, data):
        payload = json.dumps(data, ensure_ascii=False).encode('utf-8')
        self.send_response(code)
        if self.allowed():
            self.send_header('Access-Control-Allow-Origin', ORIGIN)
            self.send_header('Vary', 'Origin')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(payload)))
        self.end_headers()
        try:
            self.wfile.write(payload)
        except (BrokenPipeError, ConnectionResetError):
            pass
    def do_OPTIONS(self):
        if not self.allowed():
            self.respond(403, {'error':'Origen no autorizado.'})
            return
        self.send_response(204)
        self.send_header('Access-Control-Allow-Origin', ORIGIN)
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, X-Entorno-Token')
        self.send_header('Access-Control-Allow-Private-Network', 'true')
        self.send_header('Access-Control-Max-Age', '600')
        self.send_header('Vary', 'Origin')
        self.end_headers()
    def do_GET(self):
        if not self.allowed():
            self.respond(403, {'error':'Origen no autorizado.'})
            return
        if self.path != '/health':
            self.respond(404, {})
            return
        connected = False
        try:
            with connect_console(self.server.game_port):
                connected = True
        except OSError:
            pass
        self.respond(200, {'bridge':'entorno-fivem','version':1,'connected':connected,'token':TOKEN})
    def do_POST(self):
        global LAST_SEND
        if not self.allowed() or not hmac.compare_digest(self.headers.get('X-Entorno-Token','').encode('utf-8'), TOKEN.encode('ascii')):
            self.respond(403, {'error':'Sesión no autorizada. Recarga la web.'})
            return
        if self.path != '/execute':
            self.respond(404, {})
            return
        if self.headers.get('Content-Type','').split(';')[0] != 'application/json':
            self.respond(415, {'error':'Formato no válido.'})
            return
        try:
            length = int(self.headers.get('Content-Length','0'))
            if length <= 0 or length > 24000:
                raise ValueError('Solicitud demasiado grande o vacía.')
            self.connection.settimeout(3)
            body = json.loads(self.rfile.read(length))
            if not isinstance(body, dict):
                raise ValueError('Solicitud no válida.')
            command = normalize_command(body.get('text'), self.server.slash)
        except (ValueError, OSError) as exc:
            self.respond(400, {'error':str(exc)})
            return
        with SEND_LOCK:
            if time.monotonic() - LAST_SEND < 2:
                self.respond(429, {'error':'Espera dos segundos antes de repetir el envío.'})
                return
            try:
                with connect_console(self.server.game_port) as sock:
                    time.sleep(0.04)
                    sock.sendall(frame(command))
                    # Da tiempo a que el cliente procese el paquete antes de cerrar.
                    time.sleep(0.08)
                LAST_SEND = time.monotonic()
            except OSError:
                self.respond(503, {'error':'No se puede conectar con FiveM. Abre el juego y entra al servidor.'})
                return
        self.respond(200, {'ok':True,'message':'Enviado a la consola. Comprueba su publicación en el juego.'})


def show_message(text, error=False):
    import ctypes
    ctypes.windll.user32.MessageBoxW(None, text, 'Puente de /entornos', 0x10 if error else 0x40)

def run_tray(server):
    import pystray
    from PIL import Image, ImageDraw
    image = Image.new('RGBA', (64,64), (0,0,0,0))
    draw = ImageDraw.Draw(image)
    draw.rounded_rectangle((2,2,62,62), radius=15, fill='#963441')
    draw.rounded_rectangle((12,13,52,43), radius=5, fill='#f1e8d3')
    draw.polygon([(19,40),(19,53),(34,40)], fill='#f1e8d3')
    draw.line((37,20,27,36), fill='#963441', width=5)
    def open_web(icon=None, item=None):
        try:
            opened = webbrowser.open(WEB_URL)
        except Exception:
            opened = False
        if not opened:
            show_message('No se pudo abrir el navegador. Abre esta dirección manualmente:\n\n' + WEB_URL)
    def edit_site(icon=None, item=None):
        try:
            if not CONFIG_PATH.exists():
                CONFIG_PATH.write_text(json.dumps({'web_url': WEB_URL}, indent=2), encoding='utf-8')
            os.startfile(str(CONFIG_PATH), 'edit')
        except Exception:
            show_message('Edita el archivo configuracion.json junto al ejecutable y después pulsa «Recargar configuración».', True)
    def reload_site(icon=None, item=None):
        try:
            load_site_config()
            show_message('Dirección actualizada. Recarga la web en el navegador:\n\n' + WEB_URL)
        except Exception as error:
            show_message('No se pudo cargar la configuración. Se conserva la dirección anterior.\n\n' + str(error), True)
    def view_site(icon=None, item=None):
        show_message('Web configurada:\n' + WEB_URL + '\n\nOrigen autorizado:\n' + ORIGIN)
    def status(icon=None, item=None):
        try:
            with connect_console(server.game_port):
                state = 'Consola de FiveM disponible.'
        except OSError:
            state = 'FiveM no está disponible. Abre el juego y entra al servidor.'
        show_message('El puente está activo en la bandeja.\n\n' + state + '\n\nEl botón de la web aparecerá al detectar el puente.')
    def quit_bridge(icon, item):
        server.shutdown()
        server.server_close()
        icon.stop()
    icon = pystray.Icon('entorno-fivem', image, 'Puente /entornos — activo', menu=pystray.Menu(
        pystray.MenuItem('Abrir generador', open_web, default=True),
        pystray.MenuItem('Comprobar estado', status),
        pystray.MenuItem('Ver dirección de la web', view_site),
        pystray.MenuItem('Editar dirección de la web', edit_site),
        pystray.MenuItem('Recargar configuración', reload_site),
        pystray.Menu.SEPARATOR,
        pystray.MenuItem('Cerrar puente', quit_bridge)))
    threading.Thread(target=server.serve_forever, daemon=True).start()
    icon.run()
    server.shutdown()
    server.server_close()

def main():
    parser = argparse.ArgumentParser(description='Puente local para Generador de /entornos')
    parser.add_argument('--slash', action='store_true', help='Enviar /entorno en lugar de entorno')
    parser.add_argument('--cl2', action='store_true', help='Usar consola CL2 (29300)')
    parser.add_argument('--console', action='store_true', help='Modo consola para diagnóstico con Python')
    args = parser.parse_args()
    try:
        load_site_config()
    except Exception as error:
        if args.console:
            print('Configuración no válida: ' + str(error))
        else:
            show_message('Corrige configuracion.json antes de iniciar el puente.\n\n' + str(error), True)
        return
    try:
        server = BridgeServer((HOST, PORT), Handler)
    except OSError:
        if args.console:
            print('El puente ya está abierto o el puerto está ocupado.')
        else:
            show_message('El puente ya está abierto o el puerto local está ocupado. Busca su icono en la bandeja junto al reloj.', True)
        return
    server.game_port = 29300 if args.cl2 else 29200
    server.slash = args.slash
    if not args.console:
        try:
            run_tray(server)
        except Exception:
            server.server_close()
            show_message('No se ha podido abrir el icono de bandeja. Cierra otras instancias e inténtalo de nuevo.', True)
        return
    print('Puente activo: '+ORIGIN)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()

if __name__ == '__main__':
    main()

@echo off
start "" "%~dp0Puente-Entornos.exe" --slash
exit
